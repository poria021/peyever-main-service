export interface Services {
  service_name: string;

  currency_name: string;

  price: number;

  show_service_on: string;
}
