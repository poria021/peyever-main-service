export interface Markups {
  markup: number;

  flight_id: number;

  type_markup: string;

  markup_startdate: Date;

  markup_enddate: Date;
}
