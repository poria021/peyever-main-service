export interface MarkupParams {
  origin_city: number;
  destination_city: number;
  start_date: Date;
  end_date: Date;
}
